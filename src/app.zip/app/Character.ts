export default class Character {
    actor_name: String;
    character_name: String;
    gender: String;
    status: String;
}